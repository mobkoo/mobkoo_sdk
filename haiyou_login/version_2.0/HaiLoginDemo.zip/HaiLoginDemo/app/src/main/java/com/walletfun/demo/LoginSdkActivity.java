package com.walletfun.demo;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.EditText;

import com.facebook.FacebookException;
import com.google.android.gms.common.api.ApiException;
import com.walletfun.common.app.WalletHelp;
import com.walletfun.login.WalletLoginCallback;
import com.walletfun.login.WalletLoginHelper;
import com.walletfun.login.WalletLoginResult;
import com.walletfun.login.WalletLoginSdk;
import com.walletfun.login.WalletLoginStatus;
import com.walletfun.login.WalletUser;
import com.walletfun.login.WalletUserCallback;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * @author Jzfox <jz_boy@163.com>
 * @version 1.0
 * @date 2018/11/2 15:29
 * @description
 * @copyright ©2018 www.jzfox.net All rights reserved.
 */
public class LoginSdkActivity extends AppCompatActivity {

    @BindView(R.id.edit_result)
    EditText resultEdit;
    String googlekey = "你的GOOGLEKEY";
    String appid = "你的appid";
    String key = "你的key";


    @Override

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_sdk);
        ButterKnife.bind(this);
        //   resultEdit.setMovementMethod(ScrollingMovementMethod.getInstance());
        init();
    }

    // 登录主要使用的类
    private WalletLoginHelper helper;

    private void init() {
        //将登录SDK加入到公共模块
        WalletHelp.addSDK(new WalletLoginSdk(googlekey));
       /*   初始化登录SDK , 如果 appid 传 null ，则使用 AndroidManifest.xml 中的 配置 ，如
          <meta-data
            android:name="wallet_app_id"
            android:value="APP ID" /> 代码中的优先使用

          初始化公共参数 appid （测试id） 加密秘钥key  沙盒模式（沙盒模式暂时只有充值使用）；*/
        WalletHelp.init(this, appid, key, WalletHelp.SANDBOX_CLOSE);

        helper = WalletLoginHelper.getInstance(this);

        // 设置登录回调方法
        helper.setLoginCallback(new WalletLoginCallback() {
            @Override
            public void onResult(WalletLoginResult result) {
                // 登录结果
                switch (result.getStatus()) {
                    case WalletLoginStatus.LOGIN_SUCCESS:
                        // 成功
                        loginSuccess(result.getUser());
                        break;
                    case WalletLoginStatus.LOGIN_CANCEL:
                        // 用户取消了登录
                        resultEdit.append("\n用户取消了登录" + helper.platformName(result.getPlatform()));
                        break;
                    default:
                        // 登录失败
                        resultEdit.append("\n登录失败：" + helper.platformName(result.getPlatform()));
                        loginFailure(result.getPlatform(), result.getFailed());
                        break;
                }
            }
        });

        // 获取上次的登录信息是否有效，谷歌登录的暂时不能获取
        helper.hrtUser(new WalletUserCallback() {
            @Override
            public void onUserResult(WalletUser user) {
                // 如果为 null 则说明登录过期，或者是谷歌登录
                if (user == null) {
                    resultEdit.append("请重新登录");
                } else {
                    loginSuccess(user);
                }
            }
        });

    }

    private void loginSuccess(WalletUser user) {
        resultEdit.append("\n");
        resultEdit.append("\n登录的平台：" + helper.platformName(user.getPlatform()));
        resultEdit.append("\n平台ID:" + user.getLoginPlatformId());
        resultEdit.append("\nToken:" + user.getAccessToken());
        resultEdit.append("\n邮箱:" + user.getEmail());

        // 游客登录的时候一般没有，自己给游客取个名字吧
        resultEdit.append("\n昵称:" + user.getNickname());
        // 登录的用户名，一般没有
        resultEdit.append("\n用户名:" + user.getUsername());

        resultEdit.append("\n头像:" + user.getUserIcon());

        // 其他信息
        // 性别，一般无 0 : 未知 ; 1 : 男 ; 2 : 女
        user.getGender();


    }

    private void loginFailure(int platform, Object exception) {

        resultEdit.append("\n");
        switch (platform) {
            case WalletLoginHelper.LOGIN_PLATFORM_FACEBOOK:

                if (exception instanceof FacebookException) {
                    resultEdit.append("\nFacebook登录失败:" + exception.toString());
                }
                break;


            case WalletLoginHelper.LOGIN_PLATFORM_GOOGLE:

                if (exception instanceof ApiException) {
                    resultEdit.append("\nGoogle登录失败：" + ((ApiException) exception).getStatusCode());
                }

                break;
            case WalletLoginHelper.REQUEST_LOGIN_HAIYOU:

            case WalletLoginHelper.LOGIN_PLATFORM_GUEST:

                if (exception instanceof Exception) {
                    resultEdit.append("\n" + helper.platformName(platform) + ":" + exception.toString());
                }
                break;
            default:
                resultEdit.append("\n ----- 看到此消息联系开发人员！------------");
                break;

        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        // 很重要的一步，自己使用 startActivityForResult 时，requestCode 请不要设置成 10001 到 10005
        if (helper.handlerActivityResult(requestCode, resultCode, data)) return;
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (helper != null) helper.onConfigurationChanged(newConfig);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (helper != null) helper.destroy();
    }

    @OnClick({R.id.btn_login_default, R.id.btn_login_facebook, R.id.btn_login_google, R.id.btn_login_hai, R.id.btn_login_guest})
    public void onClick(View view) {

        resultEdit.append("\n");

        switch (view.getId()) {
            case R.id.btn_login_default:
                // 使用sdk 默认登录框
                helper.showLogin(WalletLoginHelper.LOGIN_DEFAULT);
                break;
            case R.id.btn_login_facebook:
                // 单独使用facebook
                helper.showLogin(WalletLoginHelper.LOGIN_PLATFORM_FACEBOOK);
                break;
            case R.id.btn_login_google:
                helper.showLogin(WalletLoginHelper.LOGIN_PLATFORM_GOOGLE);
                break;
            case R.id.btn_login_hai:
                helper.showLogin(WalletLoginHelper.LOGIN_PLATFORM_HAIYOU);
                break;
            case R.id.btn_login_guest:
                helper.showLogin(WalletLoginHelper.LOGIN_PLATFORM_GUEST);
                break;

        }
    }
}
