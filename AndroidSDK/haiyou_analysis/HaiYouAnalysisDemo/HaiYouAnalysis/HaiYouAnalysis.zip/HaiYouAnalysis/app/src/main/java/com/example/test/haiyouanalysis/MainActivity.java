package com.example.test.haiyouanalysis;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.haiyou_analysis.HaiYouAnalysis;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    protected Button btn2;
    protected Button btn3;
    protected Button btn4;
    protected Button btn5;
    private static final String talkingData_APPID = "E96330E98A0F43E3918E43C444E3D7C2";
    private static final String appsfly_DEVKEY = "dz2eqVEhio3jEBLnTwkUw4";
    private String TAG = "统计 ";


    public String orderID = "";
    public String goodsName = "";
    public double currencyAmount = 0;
    public String currencyType = "USD";
    public String paymentType = "HaiYouPaySDK";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.setContentView(R.layout.activity_main);
        initView();
        /* 启动 直接调用初始化*/
        HaiYouAnalysis.init(this, appsfly_DEVKEY, talkingData_APPID);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btn3) {
            /*
             *获取用户信息后调用
             *useID 用户ID  不需要账号系统时 传 ”“
             */
            HaiYouAnalysis.loginInUser("用户ID");
        } else if (view.getId() == R.id.btn4) {
            /*
                   支付成功后调用
             * @orderId ：  订单ID 确保每次订单的orderID唯一
             * @iapId ： 商品名称
             * @currencyAmount ： 现金金额或现金等价物的额度
             * @currencyType ： 货币类型。例：人民币 CNY；美元 USD；欧元 EUR
             * @paymentType ： 支付的途径，最多16个字符。例如：“支付宝”、“苹果官方”、“XX 支付SDK*/
            orderID = "Order" + System.currentTimeMillis();
            HaiYouAnalysis.PayReport(this, orderID, goodsName, currencyAmount, currencyType, paymentType);
        }
    }

    private void initView() {
        btn2 = (Button) findViewById(R.id.btn2);
        btn2.setOnClickListener(MainActivity.this);
        btn3 = (Button) findViewById(R.id.btn3);
        btn3.setOnClickListener(MainActivity.this);
        btn4 = (Button) findViewById(R.id.btn4);
        btn4.setOnClickListener(MainActivity.this);
        btn5 = (Button) findViewById(R.id.btn5);
        btn5.setOnClickListener(MainActivity.this);
    }
}
